//
//  MTPLTabBar.h
//  MTPLTabBar
//
//  Created by Ankit Patel on 06/02/20.
//  Copyright © 2020 Moweb. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MTPLTabBar.
FOUNDATION_EXPORT double MTPLTabBarVersionNumber;

//! Project version string for MTPLTabBar.
FOUNDATION_EXPORT const unsigned char MTPLTabBarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MTPLTabBar/PublicHeader.h>


